<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body >

<header class="w3-container w3-teal" style="text-align: center;">
  <h1>Parents Monitoring System</h1>
</header>

<div class="w3-container w3-half w3-margin-top" style="margin:auto;float:none;">

<form class="w3-container w3-card-4">
<p>
<label>Email</label>
<input class="w3-input" type="text" style="width:90%" required></p>
<label>Password</label>
<input class="w3-input" type="text" style="width:90%" required></p>
<p>
<button class="w3-button w3-section w3-teal w3-ripple" style="text-align: center;"> Log in </button></p>

</form>

</div>

</body>
</html> 
